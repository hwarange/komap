# sub6 분석 코드 준비본

이 묶음은 최종 채택 sub6의 추론 소스, 환경 YAML, 실행 진입점, 합금 단위 5-fold 분할 정보와 면적분율 활용 예제를 담은 코드 준비본입니다. 공모전 제출 또는 새 환경에서의 완전한 재현 검증이 완료되었다는 뜻은 아닙니다.

## 실행 위치

압축을 푼 폴더를 프로젝트 루트로 사용합니다. 상세 설치 방법과 모델 설명은 `delivery/sub6_repro/README.md`에 있습니다. 실행 파일은 Python 진입점이며 독립 `.exe`가 아닙니다.

```bash
python delivery/sub6_repro/run_submission.py --check --project-root . --out submissions/sub6_reproduced
python delivery/sub6_repro/run_submission.py --run --gpu 0 --project-root . --out submissions/sub6_reproduced
```

첫 명령은 읽기 전용 검사입니다. 두 번째 명령은 비어 있는 GPU를 명시적으로 선택하여 추론합니다. 기본 실행도 읽기 전용 검사이며, 기존 출력 폴더를 재사용하거나 학습을 시작하지 않습니다.

## 별도로 준비할 입력

- `runs/cv/x2_mit_bw_r90/fold0..4/last.pt`와 `runs/cv/x3_unetpp_bw_e120_r90/fold0..4/last.pt`: 총 10개, 1,072,482,650 bytes(약 1.07 GB).
- `data/test/images/`: 공모전 test 원본 이미지 10장.
- 파일별 정확한 경로·크기·SHA-256은 `delivery/sub6_repro/manifest.json`에 기록했습니다.

대회 데이터, 학습 체크포인트, 비밀키, 환경 캐시, 기존 실험 실행 스크립트는 이 묶음에 포함하지 않습니다. 기존 결과물 마스크 ZIP도 별도 파일로 유지합니다. 추론에는 train/valid 이미지나 예전 확률 파일이 필요하지 않습니다. 전체 분석 소스의 일부는 별도 학습 데이터·예측 파일을 필요로 하므로, 제출용 실행 경로는 위 진입점을 사용합니다.

## 면적분율 활용 예제

`reports/phase_application/`의 세 파일은 기존 sub6 마스크 10장에서 계산한 예측 2차원 상별 면적분율과 검사 기록입니다. 실제 조성·체적분율·물성·정확도를 측정한 결과가 아닙니다. 새로운 추론 결과를 분석하려면 다음 명령을 사용합니다.

```bash
python scripts/summarize_phase_masks.py --mask-dir submissions/sub6_reproduced/masks --out-dir reports/new_phase_application --expected-count 10 --plot
```

## 준비 및 검증 범위

원래 서버에서 소스 4개·체크포인트 10개·test 입력 10개와 핵심 환경 버전의 읽기 전용 검사는 통과했습니다. 이 준비본은 ZIP 목록·CRC·추출 후 파일 해시, manifest 및 분할 경로, 기본 CLI 동작을 확인했습니다. 새 환경 설치 및 이 진입점으로 GPU 전체 추론을 다시 실행하는 검증은 아직 수행하지 않았습니다. 기존 프로젝트의 과거 검증 기록 경로는 상세 README에 참고로 적었으며 해당 과거 실행 디렉터리는 이 묶음에 넣지 않았습니다.
